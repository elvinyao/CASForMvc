### New in 1.1.0 (Released 2017/08/10)

* Updated README file.
* GitHub Issue #44
* GitHub Issue #47
* GitHub Issue #54
* GitHub Issue #56
* GitHub Issue #58
* GitHub Issue #60

### New in 1.0.2 (Released 2015/05/27)

* See GitHub repository history.

### New in 1.0.1 (Released 2011/04/06)

* See GitHub repository history.

### New in 1.0.0 (Released 2011/02/28)

* See GitHub repository history.